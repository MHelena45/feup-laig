/**
 * MySphere
 * Sphere is center in origin
 * @constructor
 * @param scene - Reference to MyScene object
 * @param id - Objects id
 * @param radius - radius of the sphere
 * @param slices - number of divisions between poles
 * @param stacks - number of divisions around axis
 *
 */
class MySphere extends CGFobject {
	constructor(scene, id, radius, slices, stacks) {
		super(scene);
        this.radius = radius;
        this.slices = slices;
        this.stacks = stacks;

		this.initBuffers();
	}
	
	initBuffers() {
		this.vertices = [];
        this.indices = [];
        this.normals = [];
        this.texCoords = [];

        let theta = (Math.PI / 2) / this.stacks;
        let fi = (2 * Math.PI) / this.slices;

        for(let i = 0; i <= this.stacks * 2; i++) {
            for(let j = 0; j <= this.slices; j++) {
                this.vertices.push(
                    this.radius * Math.cos((i-this.stacks) * theta) * Math.cos(j * fi),
                    this.radius * Math.cos((i-this.stacks) * theta) * Math.sin(j * fi),
                    this.radius * Math.sin((i-this.stacks) * theta)
                );
                //size is used to normalize the normals
                let size = Math.sqrt( Math.pow(Math.cos((i-this.stacks) * theta) * Math.cos(j * fi), 2) +
                Math.pow(Math.cos((i-this.stacks) * theta) * Math.sin(j * fi),2) +
                Math.pow(Math.sin((i-this.stacks) * theta),2));

                this.normals.push(
                    (Math.cos((i-this.stacks) * theta) * Math.cos(j * fi) )/size,
                    (Math.cos((i-this.stacks) * theta) * Math.sin(j * fi)) / size,
                    Math.sin((i-this.stacks) * theta) /size
                );

                this.texCoords.push(
                    j / this.slices,
                    1 - (i / (this.stacks * 2))
                );
            }
        }

        for(let i = 0; i < this.stacks * 2; i++) {
            for(let j = 0; j < this.slices; j++) {
                this.indices.push(
                    i * (this.slices + 1) + j,
                    i * (this.slices + 1) + 1 + j,
                    (i + 1) * (this.slices + 1) + j
                );

                this.indices.push(
                    i * (this.slices + 1) + 1 + j,
                    (i + 1) * (this.slices + 1) + 1 + j,
                    (i + 1) * (this.slices + 1) + j
                );
            }
        }
        
        this.primitiveType = this.scene.gl.TRIANGLES;
        this.initGLBuffers();
    }

    /**
     * In this work doesn't have to be implemented
     * @param {value of the length_u in texture} length_u 
     * @param {value of the length_v in texture} length_v 
     */
    updateTexCoords(length_u, length_v) {	  }
}



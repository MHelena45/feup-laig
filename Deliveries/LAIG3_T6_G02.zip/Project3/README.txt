﻿Grupo T06G02

Gonçalo José Marantes Pimenta da Costa Monteiro
Maria Helena Viegas Oliveira Ferreira